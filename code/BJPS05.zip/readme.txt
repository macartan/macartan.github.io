
Enclosed are data and stata do files to replicate results published in Humphreys and Bates 2005.

To replicate the tables users should install the outreg command: ssc install outreg

Please note that unfortunately, as noted in the text of the article, the CPIA measure (the internal measure used by 
the World Bank) was provided to the authors under condition that it would not be made public. Hence datasets 
only include data for one of the two dependent variables used in this article (QUAL).

  
