

Instructions for replicating tables and figures from

   Humphreys, Macartan and Jeremy Weinstein, 2006. 
   "Handling and Manhandling Civilians in Civil War." 
   _American Political Science Review_ 100(3):429-447

The dataset is provided in STATA format (www.stata.com); 
the replication "do-file" can be run also in STATA.
  
Place the base dataset SLXC_APSR06.dta and the replication 
do file runrun.do in the same (preferably empty) directory.  
The results can then be replicated by STATA by double 
clicking on  "runrun.do" The resulting tables and figures 
are stored in the same folder as the do file and data.

Note that to run this do file you should have the "outreg" 
command  installed.  This can normally be done by typing: 
ssc install outreg 

The survey instrument underlying this data along with a report on 
the data  and description of methods is available on 
http://www.columbia.edu/~mh2245/SL.htm  
