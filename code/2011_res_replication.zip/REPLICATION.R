
rm(list = ls())

library(foreign)

detach(DATA)

DATA <- read.dta('ssaone2.dta')

attach(DATA)

# In what follows tau_x is the within-stratum treatment effect, w_x and p_x are the strata shares and probability of treatment respectively

tau     =function(y,x,t){sapply(1:length(y), function(i) mean(y[(x==x[i]) & (t==1)])- mean(y[(x==x[i]) & (t==0)]))}
ATE     =function(tau_x,p_x,w_x){sum(tau_x*w_x)/(sum(w_x))}  
ATT     =function(tau_x,p_x,w_x){sum(p_x*tau_x*w_x)/(sum(p_x*w_x))}
ATC     =function(tau_x,p_x,w_x){sum((1-p_x)*tau_x*w_x)/(sum((1-p_x)*w_x))}
b_OLS   =function(tau_x,p_x,w_x){sum(p_x*(1-p_x)*tau_x*w_x)/(sum(p_x*(1-p_x)*w_x))}


X = function(nonwhite,cpiadjust, D, P, W)
    {
    Z=matrix(NA, 18, 6) # Matrix to store results
 
    for(yr in 74:91){
    I=(year==yr & dvet==1 & dnwhite==nonwhite)
    Z[yr-73,1] = yr
    TT = (((cpiadjust*(D/cpi) +(1-cpiadjust)*D))/1000)[I] 
    PT = P[I]
    WT = W[I]
    b  =b_OLS(TT, PT, WT)    
    Z[yr-73,2] = ((b>ATT(TT, PT, WT)) & (b>ATC(TT, PT, WT)))  | ((b<ATT(TT, PT, WT)) & (b<ATC(TT, PT, WT)))  
    Z[yr-73,3] = ATE(TT, PT, WT)
    Z[yr-73,4] = ATT(TT, PT, WT)
    Z[yr-73,5] = ATC(TT, PT, WT)
    Z[yr-73,6] = b
    }
    Z}



DYADJ = DY/(1000*cpi) # Adjustment of the income variable

pdf("angrist.pdf", width=8.5, height=8)

# par(mar=c(5,4,2,1), fig=c(0,1,0,.5))
par(mar=c(5,4,2,1))

layout(matrix(c(5,5,6,6, 5,5,6,6, 1,2,3,4),byrow=TRUE, ncol=4),
        respect=TRUE)
 #layout.show(1)


graph_gap_new = function(X3, title){
    plot(X3[,1],X3[,3], type="l" , ylim=c(-1,3.2), xlab="Year", ylab="Earnings gap ('000 USD)", main=list(title, cex=1.2))
    polygon(c(X3[,1], rev(X3[,1])), c(X3[,4],rev(X3[,5])), col="grey")
    lines(X3[,1],X3[,3], type="l")
    points(X3[,1], X3[,6], pch=(19+X3[,2]*2), cex=1.2)  # OLS colored if above range 
    

    lines(X3[,1],0*X3[,1])}

panel = function(x, y, subscripts, title){
                        plot(x[subscripts], y[subscripts], col = "gray75", cex=.2, pch=16, xlab="p", ylab=expression(tau), ylim=c(-8,8), xlim=c(0,.9), main=list(title, cex=1))
                        lines(smooth.spline(probvet[subscripts], DYADJ[subscripts], w=vetcount[subscripts], spar=.75), lwd = 1,col = "black")}
 panel(probvet, DYADJ, (year<85 & dnwhite==0), "White sample, 1974-84")
 panel(probvet, DYADJ, (year>=85 & dnwhite==0), "White sample, 1985-91")
 panel(probvet, DYADJ, (year<85 & dnwhite==1), "Nonwhite sample, 1974-84")
 panel(probvet, DYADJ, (year>=85 & dnwhite==1), "Nonwhite sample, 1985-91")
 graph_gap_new(X(0,1,  DY, probvet, vetcount), "Effect of service on wages (White sample)")
 graph_gap_new(X(1,1,  DY, probvet, vetcount), "Effect of service on wages (Nonwhite sample)")

dev.off()


